package fr.telecommande.tv

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Mini encodeur/décodeur protobuf (suffisant pour le protocole Google TV). */
object Pb {
    fun varint(v: Long): ByteArray {
        val o = ByteArrayOutputStream()
        var x = v
        while (true) {
            val b = (x and 0x7F).toInt()
            x = x ushr 7
            if (x == 0L) { o.write(b); break }
            o.write(b or 0x80)
        }
        return o.toByteArray()
    }

    fun int(f: Int, v: Int): ByteArray = varint((f shl 3).toLong()) + varint(v.toLong())
    fun bytes(f: Int, b: ByteArray): ByteArray =
        varint(((f shl 3) or 2).toLong()) + varint(b.size.toLong()) + b
    fun str(f: Int, s: String): ByteArray = bytes(f, s.toByteArray())
    fun msg(f: Int, b: ByteArray): ByteArray = bytes(f, b)

    fun parse(b: ByteArray): Map<Int, Any> {
        val m = HashMap<Int, Any>()
        var i = 0
        fun rv(): Long {
            var r = 0L
            var s = 0
            while (true) {
                val c = b[i++].toInt() and 0xFF
                r = r or ((c and 0x7F).toLong() shl s)
                if (c < 0x80) break
                s += 7
            }
            return r
        }
        while (i < b.size) {
            val t = rv().toInt()
            val f = t ushr 3
            when (t and 7) {
                0 -> m[f] = rv()
                2 -> {
                    val l = rv().toInt()
                    m[f] = b.copyOfRange(i, i + l)
                    i += l
                }
                1 -> i += 8
                5 -> i += 4
                else -> return m
            }
        }
        return m
    }

    fun write(out: OutputStream, payload: ByteArray) {
        out.write(varint(payload.size.toLong()) + payload)
        out.flush()
    }

    fun read(inp: InputStream): ByteArray {
        var len = 0
        var s = 0
        while (true) {
            val c = inp.read()
            if (c < 0) throw IOException("Connexion fermée")
            len = len or ((c and 0x7F) shl s)
            if (c < 0x80) break
            s += 7
        }
        val buf = ByteArray(len)
        var n = 0
        while (n < len) {
            val r = inp.read(buf, n, len - n)
            if (r < 0) throw IOException("Connexion fermée")
            n += r
        }
        return buf
    }
}
