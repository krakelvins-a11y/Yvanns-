package fr.telecommande.tv

object Voice {
    private val apps = listOf(
        "youtube" to "https://www.youtube.com",
        "netflix" to "https://www.netflix.com/title",
        "disney" to "https://www.disneyplus.com",
        "prime" to "https://app.primevideo.com"
    )

    /** Interprète une phrase en français et envoie la commande. Retourne un message d'état. */
    fun handle(raw: String, r: Remote): String {
        val t = Keys.norm(raw).trim()
        for (p in listOf("ecris ", "ecrire ", "tape ", "recherche ")) {
            if (t.startsWith(p)) {
                val x = t.substring(p.length)
                r.text(x)
                return "Texte envoyé : $x"
            }
        }
        for ((nom, lien) in apps) {
            if (t.contains(nom)) {
                r.app(lien)
                return "Ouverture de $nom"
            }
        }
        val w = t.split(Regex("\\s+")).toSet()
        val son = t.contains("son") || t.contains("volume")
        return when {
            t.contains("muet") || t.contains("coupe le son") -> { r.key(Keys.MUTE); "Muet" }
            son && listOf("monte", "augmente", "plus", "hausse").any { t.contains(it) } -> {
                repeat(3) { r.key(Keys.VOL_UP) }; "Volume +"
            }
            son && listOf("baisse", "diminue", "moins", "reduis").any { t.contains(it) } -> {
                repeat(3) { r.key(Keys.VOL_DOWN) }; "Volume -"
            }
            t.contains("eteins") || t.contains("eteindre") || t.contains("allume") || t.contains("veille") -> {
                r.key(Keys.POWER); "Marche/arrêt"
            }
            t.contains("pause") || t.contains("lecture") || "play" in w || t.contains("reprends") -> {
                r.key(Keys.PLAY); "Lecture/pause"
            }
            "retour" in w -> { r.key(Keys.BACK); "Retour" }
            "accueil" in w -> { r.key(Keys.HOME); "Accueil" }
            "menu" in w -> { r.key(Keys.MENU); "Menu" }
            "ok" in w || "valide" in w || "selectionne" in w -> { r.key(Keys.OK); "OK" }
            "haut" in w -> { r.key(Keys.UP); "Haut" }
            "bas" in w -> { r.key(Keys.DOWN); "Bas" }
            "gauche" in w -> { r.key(Keys.LEFT); "Gauche" }
            "droite" in w -> { r.key(Keys.RIGHT); "Droite" }
            else -> "Commande non comprise"
        }
    }
}
