package fr.telecommande.tv

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Base64
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayInputStream
import java.io.IOException
import java.math.BigInteger
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.text.Normalizer
import java.util.Date
import java.util.concurrent.Executors
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import kotlin.concurrent.thread

/** Certificat client auto-signé, créé une fois et conservé. */
class Identity(ctx: Context) {
    val key: PrivateKey
    val cert: X509Certificate

    init {
        val p = ctx.getSharedPreferences("id", Context.MODE_PRIVATE)
        val k = p.getString("k", null)
        val c = p.getString("c", null)
        if (k != null && c != null) {
            key = KeyFactory.getInstance("RSA")
                .generatePrivate(PKCS8EncodedKeySpec(Base64.decode(k, Base64.NO_WRAP)))
            cert = parse(Base64.decode(c, Base64.NO_WRAP))
        } else {
            val g = KeyPairGenerator.getInstance("RSA")
            g.initialize(2048)
            val kp = g.generateKeyPair()
            val n = X500Name("CN=telecommande-fr")
            val t = System.currentTimeMillis()
            val h = JcaX509v3CertificateBuilder(
                n, BigInteger.valueOf(t), Date(t - 86400000L), Date(t + 7000L * 86400000L), n, kp.public
            ).build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private))
            key = kp.private
            cert = parse(h.encoded)
            p.edit()
                .putString("k", Base64.encodeToString(key.encoded, Base64.NO_WRAP))
                .putString("c", Base64.encodeToString(cert.encoded, Base64.NO_WRAP))
                .apply()
        }
    }

    private fun parse(b: ByteArray): X509Certificate =
        CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(b)) as X509Certificate
}

object Net {
    fun connect(host: String, port: Int, id: Identity): SSLSocket {
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        val pw = "x".toCharArray()
        ks.setKeyEntry("k", id.key, pw, arrayOf(id.cert))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, pw)
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, arrayOf<TrustManager>(tm), null)
        val raw = Socket()
        raw.connect(InetSocketAddress(host, port), 6000)
        val s = ctx.socketFactory.createSocket(raw, host, port, true) as SSLSocket
        s.startHandshake()
        return s
    }
}

/** Association (port 6467) : la TV affiche un code à 6 caractères. */
class Pairing(private val host: String, private val id: Identity) {
    private var sock: SSLSocket? = null
    private val hdr = Pb.int(1, 2) + Pb.int(2, 200)

    private fun send(body: ByteArray) = Pb.write(sock!!.outputStream, hdr + body)

    private fun expect(field: Int) {
        val m = Pb.parse(Pb.read(sock!!.inputStream))
        if ((m[2] as? Long) != 200L) throw IOException("Refusé par la TV (${m[2]})")
        if (!m.containsKey(field)) throw IOException("Réponse inattendue de la TV")
    }

    fun start() {
        sock = Net.connect(host, 6467, id)
        send(Pb.msg(10, Pb.str(1, "atvremote") + Pb.str(2, "Telecommande FR")))
        expect(11)
        val enc = Pb.int(1, 3) + Pb.int(2, 6)
        send(Pb.msg(20, Pb.msg(1, enc) + Pb.int(3, 1)))
        expect(20)
        send(Pb.msg(30, Pb.msg(1, enc) + Pb.int(2, 1)))
        expect(31)
    }

    private fun strip(b: BigInteger): ByteArray {
        val a = b.toByteArray()
        return if (a.size > 1 && a[0] == 0.toByte()) a.copyOfRange(1, a.size) else a
    }

    fun finish(codeIn: String) {
        val code = codeIn.trim()
        if (code.length != 6) throw IOException("Le code doit avoir 6 caractères")
        val cb = try {
            ByteArray(3) { code.substring(2 * it, 2 * it + 2).toInt(16).toByte() }
        } catch (e: NumberFormatException) {
            throw IOException("Code invalide (0-9 et A-F)")
        }
        val s = sock ?: throw IOException("Pas de connexion")
        val srv = s.session.peerCertificates[0].publicKey as RSAPublicKey
        val cli = id.cert.publicKey as RSAPublicKey
        val md = MessageDigest.getInstance("SHA-256")
        md.update(strip(cli.modulus))
        md.update(strip(cli.publicExponent))
        md.update(strip(srv.modulus))
        md.update(strip(srv.publicExponent))
        md.update(cb.copyOfRange(1, cb.size))
        val secret = md.digest()
        if (secret[0] != cb[0]) throw IOException("Code incorrect")
        send(Pb.msg(40, Pb.bytes(1, secret)))
        expect(41)
        s.close()
    }

    fun cancel() {
        try { sock?.close() } catch (_: Exception) {}
    }
}

object Keys {
    const val HOME = 3
    const val BACK = 4
    const val UP = 19
    const val DOWN = 20
    const val LEFT = 21
    const val RIGHT = 22
    const val OK = 23
    const val VOL_UP = 24
    const val VOL_DOWN = 25
    const val POWER = 26
    const val MENU = 82
    const val PLAY = 85
    const val MUTE = 164

    fun norm(t: String): String =
        Normalizer.normalize(t.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    fun fromText(t: String): List<Int> = norm(t).mapNotNull { c ->
        when (c) {
            in 'a'..'z' -> 29 + (c - 'a')
            in '0'..'9' -> 7 + (c - '0')
            ' ' -> 62
            '.' -> 56
            ',' -> 55
            '-' -> 69
            else -> null
        }
    }
}

/** Télécommande (port 6466). Toutes les commandes passent par un fil unique. */
class Remote(
    private val host: String,
    private val id: Identity,
    private val onState: (String) -> Unit
) {
    private var sock: SSLSocket? = null
    @Volatile private var ready = false
    private val ex = Executors.newSingleThreadExecutor()

    private fun write(s: SSLSocket, payload: ByteArray) {
        synchronized(s) { Pb.write(s.outputStream, payload) }
    }

    private fun open() {
        try { sock?.close() } catch (_: Exception) {}
        ready = false
        val s = Net.connect(host, 6466, id)
        sock = s
        thread(isDaemon = true) { loop(s) }
        var n = 0
        while (!ready && n++ < 80) Thread.sleep(50)
        if (!ready) throw IOException("La TV ne répond pas")
    }

    private fun loop(s: SSLSocket) {
        try {
            val inp = s.inputStream
            while (true) {
                val m = Pb.parse(Pb.read(inp))
                if (m.containsKey(1)) {
                    val info = Pb.str(1, "Telecommande") + Pb.str(2, "FR") + Pb.int(3, 1) +
                        Pb.str(4, "1") + Pb.str(5, "fr.telecommande.tv") + Pb.str(6, "1.0.0")
                    write(s, Pb.msg(1, Pb.int(1, 622) + Pb.msg(2, info)))
                }
                if (m.containsKey(2)) {
                    write(s, Pb.msg(2, Pb.int(1, 622)))
                    ready = true
                    onState("Connecté")
                }
                val ping = m[8] as? ByteArray
                if (ping != null) {
                    val v = ((Pb.parse(ping)[1] as? Long) ?: 1L).toInt()
                    write(s, Pb.msg(9, Pb.int(1, v)))
                }
            }
        } catch (e: Exception) {
            if (sock === s) { ready = false; onState("Déconnecté") }
        }
    }

    private fun task(block: (SSLSocket) -> Unit) {
        ex.execute {
            try {
                if (!ready || sock?.isClosed != false) open()
                block(sock!!)
            } catch (e: Exception) {
                onState("Erreur : ${e.message}")
            }
        }
    }

    private fun keyMsg(code: Int) = Pb.msg(10, Pb.int(1, code) + Pb.int(2, 3))

    fun warmUp() = task { }
    fun key(code: Int) = task { s -> write(s, keyMsg(code)) }
    fun app(link: String) = task { s -> write(s, Pb.msg(90, Pb.str(1, link))) }
    fun text(t: String) = task { s ->
        for (c in Keys.fromText(t)) {
            write(s, keyMsg(c))
            Thread.sleep(40)
        }
    }

    fun close() {
        try { sock?.close() } catch (_: Exception) {}
        ex.shutdown()
    }
}

/** Détection automatique des TV Google TV sur le Wi-Fi. */
class Discover(ctx: Context, private val onFound: (String) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var busy = false

    private val listener = object : NsdManager.DiscoveryListener {
        override fun onStartDiscoveryFailed(t: String?, c: Int) {}
        override fun onStopDiscoveryFailed(t: String?, c: Int) {}
        override fun onDiscoveryStarted(t: String?) {}
        override fun onDiscoveryStopped(t: String?) {}
        override fun onServiceLost(i: NsdServiceInfo?) {}
        override fun onServiceFound(i: NsdServiceInfo?) {
            if (i != null) {
                synchronized(this@Discover) { queue.add(i) }
                next()
            }
        }
    }

    private fun next() {
        var item: NsdServiceInfo? = null
        synchronized(this) {
            if (busy) return
            item = queue.removeFirstOrNull()
            if (item != null) busy = true
        }
        val s = item ?: return
        try {
            nsd.resolveService(s, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo?, c: Int) { done() }
                override fun onServiceResolved(i: NsdServiceInfo?) {
                    val h = i?.host
                    if (h is Inet4Address) onFound(h.hostAddress ?: "")
                    done()
                }
            })
        } catch (e: Exception) {
            done()
        }
    }

    private fun done() {
        synchronized(this) { busy = false }
        next()
    }

    fun start() {
        try {
            nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (_: Exception) {}
    }

    fun stop() {
        try { nsd.stopServiceDiscovery(listener) } catch (_: Exception) {}
    }
}
