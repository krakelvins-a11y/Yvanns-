package fr.telecommande.tv

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private lateinit var id: Identity
    private val status = mutableStateOf("")
    private val host = mutableStateOf("")
    private val paired = mutableStateOf(false)
    private val stage = mutableStateOf(0)
    private val found = mutableStateListOf<String>()
    private var remote: Remote? = null
    private var pairing: Pairing? = null
    private var disco: Discover? = null

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        val r = remote
        if (t != null && r != null) status.value = "« $t » → " + Voice.handle(t, r)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        id = Identity(this)
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        host.value = prefs.getString("host", "") ?: ""
        paired.value = prefs.getBoolean("paired", false)
        if (paired.value) connect() else startDiscovery()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (paired.value) RemoteScreen() else PairScreen()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        disco?.stop()
        remote?.close()
        pairing?.cancel()
    }

    private fun ui(block: () -> Unit) = runOnUiThread(block)

    private fun startDiscovery() {
        disco?.stop()
        disco = Discover(this) { ip -> ui { if (ip !in found) found.add(ip) } }.also { it.start() }
    }

    private fun connect() {
        remote?.close()
        remote = Remote(host.value.trim(), id) { s -> ui { status.value = s } }.also { it.warmUp() }
    }

    private fun startPairing() {
        val h = host.value.trim()
        if (h.isEmpty()) { status.value = "Entrez l'adresse IP de la TV"; return }
        status.value = "Connexion à la TV…"
        thread {
            try {
                pairing?.cancel()
                val p = Pairing(h, id)
                p.start()
                pairing = p
                ui { stage.value = 1; status.value = "Entrez le code affiché sur la TV" }
            } catch (e: Exception) {
                ui { status.value = "Échec : ${e.message}" }
            }
        }
    }

    private fun finishPairing(code: String) {
        val p = pairing ?: return
        status.value = "Vérification…"
        thread {
            try {
                p.finish(code)
                getSharedPreferences("app", MODE_PRIVATE).edit()
                    .putString("host", host.value.trim()).putBoolean("paired", true).apply()
                ui {
                    disco?.stop()
                    paired.value = true
                    stage.value = 0
                    status.value = "Association réussie"
                    connect()
                }
            } catch (e: Exception) {
                ui { status.value = "Échec : ${e.message}" }
            }
        }
    }

    private fun unpair() {
        getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("paired", false).apply()
        remote?.close()
        remote = null
        paired.value = false
        stage.value = 0
        status.value = ""
        startDiscovery()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Dites une commande")
        try { speech.launch(i) } catch (e: Exception) { status.value = "Reconnaissance vocale indisponible" }
    }

    @Composable
    private fun RowScope.B(t: String, f: () -> Unit) {
        FilledTonalButton(
            onClick = f,
            modifier = Modifier.weight(1f).height(56.dp),
            contentPadding = PaddingValues(4.dp)
        ) { Text(t, maxLines = 1) }
    }

    @Composable
    private fun R(content: @Composable RowScope.() -> Unit) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }

    @Composable
    private fun PairScreen() {
        var code by remember { mutableStateOf("") }
        Column(
            Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Association avec la TV", style = MaterialTheme.typography.headlineSmall)
            Text("Téléphone et TV sur le même Wi-Fi, TV allumée.")
            if (stage.value == 0) {
                OutlinedTextField(
                    value = host.value, onValueChange = { host.value = it },
                    label = { Text("Adresse IP de la TV") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                for (ip in found) {
                    OutlinedButton(onClick = { host.value = ip }) { Text("TV détectée : $ip") }
                }
                Button(onClick = { startPairing() }) { Text("Associer") }
            } else {
                OutlinedTextField(
                    value = code, onValueChange = { code = it.uppercase().take(6) },
                    label = { Text("Code à 6 caractères") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { finishPairing(code) }) { Text("Valider") }
            }
            Text(status.value)
        }
    }

    @Composable
    private fun RemoteScreen() {
        var txt by remember { mutableStateOf("") }
        fun k(c: Int) { remote?.key(c) }
        Column(
            Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(status.value.ifEmpty { "Prêt" })
            R { B("⏻") { k(Keys.POWER) }; B("Muet") { k(Keys.MUTE) }; B("Vol −") { k(Keys.VOL_DOWN) }; B("Vol +") { k(Keys.VOL_UP) } }
            R { Spacer(Modifier.weight(1f)); B("▲") { k(Keys.UP) }; Spacer(Modifier.weight(1f)) }
            R { B("◀") { k(Keys.LEFT) }; B("OK") { k(Keys.OK) }; B("▶") { k(Keys.RIGHT) } }
            R { Spacer(Modifier.weight(1f)); B("▼") { k(Keys.DOWN) }; Spacer(Modifier.weight(1f)) }
            R { B("Retour") { k(Keys.BACK) }; B("Accueil") { k(Keys.HOME) }; B("⏯") { k(Keys.PLAY) } }
            R {
                B("YouTube") { remote?.app("https://www.youtube.com") }
                B("Netflix") { remote?.app("https://www.netflix.com/title") }
                B("Disney+") { remote?.app("https://www.disneyplus.com") }
                B("Prime") { remote?.app("https://app.primevideo.com") }
            }
            OutlinedTextField(
                value = txt, onValueChange = { txt = it },
                label = { Text("Texte à envoyer à la TV") }, modifier = Modifier.fillMaxWidth()
            )
            R {
                B("Envoyer le texte") { remote?.text(txt); txt = "" }
                B("🎤 Parler") { listen() }
            }
            OutlinedButton(onClick = { unpair() }) { Text("Dissocier la TV") }
        }
    }
}
